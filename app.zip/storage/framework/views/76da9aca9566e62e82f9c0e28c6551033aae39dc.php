
<?php $__env->startSection('contenido'); ?>

        <h5>Compras realizadas</h5>
        <table class="therichpost-table therichpost-striped therichpost-white">
          <tr>
          <td>foto</td>
              <td>Producto</td>
              <td>Precio</td>
              <td>cantidad</td>
              <td>Subtotal</td>
              <td>Total</td>
              
             </tr>

             <?php $__currentLoopData = $consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
             <td><img src="<?php echo e(asset('archivos/'. $consulta->fotop)); ?>" alt="Product Image" width="100" heigth="100"></td>
                  <td><?php echo e($consulta->producto); ?></td>
                  <td><?php echo e($consulta->precio); ?></td>
                  <td><?php echo e($consulta->cantidad); ?></td>
                  <td><?php echo e($consulta->sub_total); ?></td>
                  <td><?php echo e($consulta->total); ?></td>
                 
                  
                  
                  
             </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
 
        </table>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_2\resources\views//vista-compras.blade.php ENDPATH**/ ?>