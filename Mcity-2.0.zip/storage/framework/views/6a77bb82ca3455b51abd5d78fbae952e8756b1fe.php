
<?php $__env->startSection('contenido'); ?>

   
                    <?php 
            $sessionusuario=session('sessionusuario');
        ?>
       <p>  <?php echo $sessionusuario?> </p>
     
        <!-- Top bar End -->
        


        <nav class="nav justify-content-end">
            <?php if(session('carrito')): ?>
                <a class="nav-link" href="<?php echo e(url('carrito')); ?>">
                El carrito contenido: <?php echo e(count(session('carrito'))); ?>Articulos
                </a>
            <?php else: ?>
                <a  class="nav-link" href="#">
                    El carrito contenido: 0 articulos
                </a>
            <?php endif; ?>
        </nav>

            <?php if($message=Session::get('success')): ?>
            <div class="alert alert-success alert-block">
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <h2>Carrito de compras</h2>
            <!----------------------------------------------------->
                <table class="table table-hover table-condensed">
                    <thead>
                        <tr>
                            <th style="width:50%">Producto</th>
                            <th style="width:10%">precio</th>
                            <th style="width:8%">Cantidad</th>
                            <th style="width:22%" class="text-center">Subtotal</th>
                            <th style="width:10%">Otros</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $total = 0 ?>
                        <?php if(session('carrito')): ?>
                        <?php $__currentLoopData = session('carrito'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idp=>$datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $total += $datos['precio'] * $datos['cantidad'] ?>
                            <form action="<?php echo e(route ( 'guardar_compra' )); ?>" method="POST" enctype = 'multipart/form-data'>
                    <?php echo e(csrf_field()); ?>

                                    <tr>
                                    <td data-th="Producto">
                                        
                                            
                                                <div class="col-sm-3 hidden-xs">
                                                    <input type="text"  style="width:270px; background:none; border:none; outline:0; font-family:Arial, Helvetica, sans-serif; margin:0; padding:0;" name="fotop" value="<?php echo e($datos['fotop']); ?>" id="">
                                                    <img src="<?php echo e(asset('archivos/'.$datos['fotop'])); ?>" width="100"  name="fotop" height="100" class="img-responsive" alt="">
                                                </div>
                                            <div class="col-sm-9">
                                                <h4 class="nomargin" name="producto">
                                                    <input type="text" style="width:270px; background:none; border:none; outline:0; font-family:Arial, Helvetica, sans-serif; margin:0; padding:0;" name="producto" value="<?php echo e($datos['producto']); ?>" id=""> </h4>
                                            </div>
                                    </td>
                                        <td data-th="precio">
                                            <input type="text" name="precio" value="$<?php echo e($datos['precio']); ?>" class="form-control quantity">    </td>
                                        <td data-th="Cantidad">
                                        <input type="number" value="<?php echo e($datos['cantidad']); ?>" min="1" name="cantidad" class="form-control quantity">
                                    </td>
                                    <td data-th="Subtotal" class="text-center">
                                        <input type="text" name="sub_total" value="<?php echo e($datos['precio']*$datos['cantidad']); ?>" class="form-control quantity"></td>
                                        <td data-th="Otros" class="actions">
                                        
                                        <button class="btn btn-danger btn-sm delete-cart" name="id" data-id="<?php echo e($idp); ?>">
                                                        <i class="fa fa-trash"></i>    
                                        </button>   
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr class="visible-xs">
                                    <td class="text-center"><strong>
                                        <input type="text" name="total" style="width:270px; background:none; border:none; outline:0; font-family:Arial, Helvetica, sans-serif; margin:0; padding:0; font-size: 0px;" value="<?php echo e($total); ?>" class="form-control quantity"></strong></td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(url('tablap')); ?>" class="btn btn-warning">
                                            <i class="fa fa-shopping-cart "> Seguir Comprando</i>
                                        </a>
                                    </td>
                                    <td colspan="2" class="hidden-xs"></td>
                                    <td class="hidden-xs-text-center"><strong>Total: $<?php echo e($total); ?></strong></td>
                                    <td>
                                        <button  class="btn btn-warning">
                                        
                                                <i class="fa fa-money  "> Confirmar compra</i>
                                            
                                        </button>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    <!------------------------------>
                <!--</form> -->

                <style>
                    .border{
                        border: 0;
                    }
                    .fondo{
                        background: white;
                    }
                </style>

     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Mcity-2.0\resources\views/carrito/carrito.blade.php ENDPATH**/ ?>